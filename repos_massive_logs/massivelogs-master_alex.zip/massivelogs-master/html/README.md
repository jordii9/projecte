# Pàgina HTML

Pàgina HTML sobre la qual farem peticions massives per tal de generar logs necessaris per al projecte. És una pàgina senzilla,
composada de diferents pàgines estàtiques per tal d'aprofundir nivells a l'hora de fer les peticions i per tant, obtenir uns logs més "interessants".

Té una mica de CSS per tal de fer-la més atractiva visualment.
