# Generació massiva de logs diversos amb un script de bash 
========
## Instruccions  
### Pas 1  
> Descarregueu el script [logGenerator.sh](logGenerator.sh).  

### Pas 2 
> Executeu el script.  

		# chmod +x loggenerator.sh  
		# ./logGenerator.sh  

### Pas 3 
> Verifiqueu si els logs s'esten generant correctament.  

		# journalctl -f
