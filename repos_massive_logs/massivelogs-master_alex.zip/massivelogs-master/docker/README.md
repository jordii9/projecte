# Docker

En la creació massiva de logs serà necessari l'ús de containers Docker, on en cada container tindrem allotjat un servei *httpd*, cadascún apuntant 
a un port diferent.

## Instruccions

A continuació, veurem els passos necessaris per arribar a crear els containers i fer servir-los, ja sigui manualment o amb els scripts
que us proporciona aquest respositori.

1.  Instal·lar Docker

  * Si tenim un sistema Fedora 20 o inferior:
  
    > sudo yum install docker-io
  
  * Si tenim un sistema Fedora 21 o superior:
  
    > sudo dnf install docker
    

2.  Iniciar el servei

  * Per activar el servei:
  
    > sudo systemctl start docker
  
  * Per comprovar que està activat:
  
    > sudo systemctl status docker
    
  * Si volem que s'activi cada vegada que arranquem l'equip:
  
    > sudo systemctl enable docker
    

3. Crear el nostre primer container

  > docker run -it fedora /bin/bash
  
  Aquesta ordre crea un container amb una imatge de fedora, que si no la tenim al nostre repositori local, veurem com la busca i la
  descarrega automàticament.
 
4. Crear la nostra imatge Apache

 Posant-nos al directori de treball adequat, on ha de ser el Dockerfile i els fitxers necessaris
 
 > docker build -t img_httpd .
 
 On:
 
 * *img_httpd* és el nom que posarem a la nostra imatge
 * *.* representa el fitxer Dockerfile

5. Crear els containers que contenen l'apache amb l'script

 > ./generateDockers.sh 3 img_httpd
 
 On:
 
 * *./generateDockers.sh* és el nom de l'script
 * *3* és el número de containers que crearem
 * *img_httpd* és la imatge a partir de la qual es crearan els containers
 
6. Arrencar els contenidors

 Segons el número que li haguem passat al programa, en aquest cas 3, per tant s'han d'arrencar
 3 contenidors, amb els nombres **httpd2**, **httpd3** i **httpd4**. Si haguéssim creat més, continuarien
 creant-se amb noms succesius.
 
 > docker start httpd2
 
 > docker start httpd3
 
 > docker start httpd4
 
7. Entrar dins els containers i editar */etc/httpd/conf/httpd.conf*
 
 A cada container haurem d'editar la directiva ServerName amb 172.17.0.X:80

 Exemple d'editar el primer container, els altres seríen igual canviant *X* pel número
 apropiat
 
 > docker attach httpd2
 
  > vi /etc/httpd/conf/httpd.conf
  
  > ServerName 172.17.0.2:80

8. Comprovar que els apaches dels containers funcionen adequadament

 Primer, mirarem els ports oberts al nostre sistema:
  
  > nmap localhost
  
 Al fer aquesta ordre hauríen d'aparéixer els ports dels serveis configurats al docker (8080 i succesius).
 
 Després, comprovar que podem entrar via navegador a la pàgina web que contenen els containers:
 
  > firefox localhost:8080 &disown
  
  
 

  
