#!/bin/bash
# Autor: Sunil Shrestha 
# Curs: Asix
# Versio: 1 
# Script que

cp my.cnf /etc/my.cnf

