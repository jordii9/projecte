# Script python

Script que genera gran quantitat de logs.

## Instruccions

1.  Descarregar l'script
2.  Donar permisos d'execució

  >chmod +x massivePython.py

3.  Executar. Al directori de treball

  > ./massivePython.py
  
4. Si és volen veure tots els logs que genera és recomendable, a un altre terminal, obrir el journal

  > journalctl -f
  
  
